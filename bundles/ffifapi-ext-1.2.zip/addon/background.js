
class Logger {
	
	error(msg) {
		console.log(msg);
	}
	
	info(msg) {
		console.log(msg);
	}
	
	debug(msg) {
		console.log(msg);
	}
	
}

var logger = new Logger();

class Main {
	
	constructor() {
		this._comm = null;
	}
	
	start() {
		this._comm = new Comm(new Handler());
		this._comm.connect();
	}
	
}

let main = new Main();

browser.runtime.onInstalled.addListener(() => {
	logger.debug('Addon installed');
	main.start();
});

browser.runtime.onStartup.addListener(() => {
	logger.debug('Addon started');
	main.start();
});

