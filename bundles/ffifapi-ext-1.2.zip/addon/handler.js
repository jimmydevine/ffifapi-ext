

class Handler {
	
	constructor() {
		this.browser = new Browser();
	}
	
	async handle(msg) {
		switch (msg.cmd)
		{
			case 'closeWindow':
				return await this.browser.closeWindow();
			case 'getTabs':
				return await this.browser.getTabs();
			case 'createTab':
				return await this.browser.createTab(msg.properties);
			case 'updateTab':
				return await this.browser.updateTab(msg.tab, msg.properties);
			case 'closeTab':
				return await this.browser.closeTab(msg.tab);
		}
		
		return false;
	}
	
	
}

