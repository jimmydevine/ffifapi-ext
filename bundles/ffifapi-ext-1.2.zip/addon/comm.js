

/*
	Websockets communication class
*/
class Comm {
	
	constructor(handler) {
		this.handler = handler;
	}
	
	connect() {
		let _this = this;
		this.webSocket = new WebSocket('ws://127.0.0.1:7777');
		this.webSocket.onerror   = function(event) { _this.onWebSocketError(event);   }
		this.webSocket.onopen    = function(event) { _this.onWebSocketOpen(event);    }
		this.webSocket.onclose   = function(event) { _this.onWebSocketClose(event);   }
		this.webSocket.onmessage = function(event) { _this.onWebSocketMessage(event); }
	}
	
	onWebSocketError(event) {
		logger.error("WebSocket error observed: " + event);
	};

	onWebSocketClose(event) {
		logger.info("WebSocket close: " + event);
		
		let _this = this;
		setTimeout(() => { _this.connect(); }, 1000);
	};

	onWebSocketOpen(event) {
		logger.info("WebSocket open: " + this.webSocket.readyState);
	};

	onWebSocketMessage(event) {
		let _this = this;
		let msg = JSON.parse(event.data);
		this.handler.handle(msg).then(function(result) {
			let response = { 'result': result };
			_this.webSocket.send(JSON.stringify(response));
		});
	}
}

