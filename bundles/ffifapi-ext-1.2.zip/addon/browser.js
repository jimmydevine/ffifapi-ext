

class Browser {
	
	
	async closeWindow() {
		let win = await browser.windows.getCurrent();
		let id = win.id;
		
		// do not await so that the response will be sent first
		browser.windows.remove(id);
		
		return true;
	}
	
	async getTabs() {
		let tabs = await browser.tabs.query({ currentWindow: true });
		
		return tabs;
	}
	
	async createTab(properties) {
		return await browser.tabs.create(properties);
	}
	
	async updateTab(tab, properties) {
		await browser.tabs.update(tab, properties);
		return true;
	}
	
	async closeTab(tab) {
		await browser.tabs.remove(tab);
		return true;
	}
	
}

