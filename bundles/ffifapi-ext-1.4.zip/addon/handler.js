


/***********************************************************************************************************************************
* Request handler class
***********************************************************************************************************************************/
class Handler {
	
	
	/*******************************************************************************************************************************
	* Request handler constructor
	*******************************************************************************************************************************/
	constructor() {
		this.browser = new Browser();
	}
	
	
	/*******************************************************************************************************************************
	* Forwards requests to the intended destination
	*******************************************************************************************************************************/
	async forward(msg) {
		logger.debug(msg);
		switch (msg.cmd)
		{
			case 'closeWindow':
				return await this.browser.closeWindow();
			case 'getTabs':
				return await this.browser.getTabs();
			case 'createTab':
				return await this.browser.createTab(msg.properties);
			case 'updateTab':
				return await this.browser.updateTab(msg.tab, msg.properties);
			case 'closeTab':
				return await this.browser.closeTab(msg.tab);
			case 'getBrowserInfo':
				return await this.browser.getBrowserInfo();
			case 'getCurrentWindowInfo':
				return await this.browser.getCurrentWindowInfo();
			case 'getContextualIdentities':
				return await this.browser.getContextualIdentities(msg.properties);
			case 'createContextualIdentity':
				return await this.browser.createContextualIdentity(msg.properties);
		}
		
		return false;
	}
	
	
}

