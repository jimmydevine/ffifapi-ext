


/***********************************************************************************************************************************
* Browser interaction class
***********************************************************************************************************************************/
class Browser {
	
	
	/*******************************************************************************************************************************
	* Close the browser window
	*******************************************************************************************************************************/
	async closeWindow() {
		let win = await browser.windows.getCurrent();
		let id = win.id;
		
		// do not await so that the response will be sent first
		browser.windows.remove(id);
		
		return true;
	}
	
	
	/*******************************************************************************************************************************
	* Get a list of tabs and associated information
	*******************************************************************************************************************************/
	async getTabs() {
		let tabs = await browser.tabs.query({ currentWindow: true });
		
		return tabs;
	}
	
	
	/*******************************************************************************************************************************
	* Create a new tab with associated properties
	*******************************************************************************************************************************/
	async createTab(properties) {
		if (!properties || typeof properties !== 'object')
		{
			return false;
		}
		return await browser.tabs.create(properties);
	}
	
	
	/*******************************************************************************************************************************
	* Update the given tab with associated properties
	*******************************************************************************************************************************/
	async updateTab(tab, properties) {
		if (!properties || typeof properties !== 'object')
		{
			return false;
		}
		await browser.tabs.update(tab, properties);
		
		return true;
	}
	
	
	/*******************************************************************************************************************************
	* Close the given tab
	*******************************************************************************************************************************/
	async closeTab(tab) {
		await browser.tabs.remove(tab);
		return true;
	}
	
	
	/*******************************************************************************************************************************
	* Returns browser information
	*******************************************************************************************************************************/
	async getBrowserInfo() {
		return browser.runtime.getBrowserInfo();
	}
	
	
	/*******************************************************************************************************************************
	* Returns information about the current window
	*******************************************************************************************************************************/
	async getCurrentWindowInfo() {
		return browser.windows.getCurrent();
	}
	
	
	/*******************************************************************************************************************************
	* Returns information about contextual identities
	*******************************************************************************************************************************/
	async getContextualIdentities(properties) {
		if (browser.contextualIdentities == undefined)
		{
			return false;
		}
		if (properties)
		{
			if (typeof properties !== 'object')
			{
				return false;
			}
			return browser.contextualIdentities.query(properties);
		}
		return browser.contextualIdentities.query({ });
	}
	
	
	/*******************************************************************************************************************************
	* Creates a new contextual identity instance with the given properties
	*******************************************************************************************************************************/
	async createContextualIdentity(properties) {
		if (browser.contextualIdentities == undefined)
		{
			return false;
		}
		if (!properties || typeof properties !== 'object')
		{
			return false;
		}
		return browser.contextualIdentities.create(properties);
	}
	
	
}

